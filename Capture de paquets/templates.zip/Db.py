from pymongo import MongoClient

def initialize_db() :
    # Connexion à la base de données MongoDB
    client_TCP = MongoClient('mongodb://localhost:27017/') 
    client_UDP = MongoClient('mongodb://localhost:27018/') 
    client_ICMP = MongoClient('mongodb://localhost:27019/') 
    client_UNKNOWN = MongoClient('mongodb://localhost:27020/') 

    # Sélection de la base de données 'traffic'
    db_TCP = client_TCP['traffic']
    db_UDP = client_UDP['traffic']
    db_ICMP = client_ICMP['traffic']
    db_UNKNOWN = client_UNKNOWN['traffic']

    # Accéder aux collections
    collection_TCP = db_TCP['packets']
    collection_UDP = db_UDP['packets']
    collection_ICMP = db_ICMP['packets']
    collection_UNKNOWN = db_UNKNOWN['packets']

    return {
        'clients': {
            'TCP': client_TCP, 
            'UDP': client_UDP, 
            'ICMP': client_ICMP, 
            'UNKNOWN': client_UNKNOWN
        },
        'collections': {
            'TCP': collection_TCP, 
            'UDP': collection_UDP, 
            'ICMP': collection_ICMP, 
            'UNKNOWN': collection_UNKNOWN
        }
    }

def insert_into_mongodb(collections, data) :
    if data['packet_type'] == "TCP":
        collections['TCP'].insert_one(data)
    elif data['packet_type'] == "UDP":
        collections['UDP'].insert_one(data)
    elif data['packet_type'] == "ICMP":
        collections['ICMP'].insert_one(data)
    else:
        collections['UNKNOWN'].insert_one(data)

def analyze_data(collections, type_req, actual_time, period ):
    type_req = type_req.upper()

    # Convert the period from hours to seconds
    period_seconds = int(period * 3600)

    # Create a timedelta object representing the time period
    # time_period = timedelta(seconds=period_seconds)

    # Calculate the minimum timestamp based on the actual time and period
    min_time = actual_time - period_seconds   
    result = []
    if type_req == 'TCP':
        print("TCP")
        packet_count_TCP = {'TCP': collections['TCP'].count_documents({"timestamp": {"$gt": min_time}})}
        sum_sizes_TCP = collections['TCP'].aggregate([
            {
                "$match": {"timestamp": {"$gt": min_time}}
            },
            {
                "$group": {"_id": None, "total": {"$sum": "$packet_size"}}
            }
        ]).next().get('total',0)
        result.append(packet_count_TCP)
        result.append(sum_sizes_TCP)
    elif type_req == 'UDP':
        print("udp")
        packet_count_UDP = {'UDP': collections['UDP'].count_documents({"timestamp": {"$gt": min_time}})}
        sum_sizes_UDP = collections['UDP'].aggregate([
            {
                "$match": {"timestamp": {"$gt": min_time}}
            },
            {
                "$group": {"_id": None, "total": {"$sum": "$packet_size"}}
            }
        ]).next().get('total',0)
        result.append(packet_count_UDP)
        result.append(sum_sizes_UDP)
    elif type_req == 'ICMP':
        print("icmp")
        packet_count_ICMP = {'ICMP': collections['ICMP'].count_documents({"timestamp": {"$gt": min_time}})}
        sum_sizes_ICMP = collections['ICMP'].aggregate([
            {
                "$match": {"timestamp": {"$gt": min_time}}
            },
            {
                "$group": {"_id": None, "total": {"$sum": "$packet_size"}}
            }
        ]).next().get('total',0)
        result.append(packet_count_ICMP)
        result.append(sum_sizes_ICMP)
    else :
        print("autre")
        sum_sizes_UNKNOWN = collections['UNKNOWN'].aggregate([
            {
                "$match": {"timestamp": {"$gt": min_time}}
            },
            {
                "$group": {"_id": None, "total": {"$sum": "$packet_size"}}
            }
        ]).next().get('total',0)
        packet_count_UNKNOWN = {'UNKNOWN': collections['UNKNOWN'].count_documents({"timestamp": {"$gt": min_time}})}
        result.append(packet_count_UNKNOWN)
        result.append(sum_sizes_UNKNOWN)
    return result

def close_db(clients) :
    for client in clients.values() :
        client.close()