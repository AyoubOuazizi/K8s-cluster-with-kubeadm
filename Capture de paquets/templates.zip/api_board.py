from dataclasses import dataclass
import sys

from flask import Flask, jsonify, render_template, request, send_from_directory
from werkzeug.exceptions import HTTPException
import Db
import time

app = Flask(__name__)

@dataclass
class Result:
    """ Classe qui comporte les résultats à renvoyer au front"""
    type_req: str
    avg_size: float
    number: int
    time_period: float

results = []

def run_analysis(type_req, period):
    #TODO: run proper analysis with back
    actual_time = time.time()
    db_info = Db.initialize_db()
    analysis_result = Db.analyze_data(db_info['collections'], type_req, actual_time, period)
    print("-----------------------------")
    print(analysis_result)
    return analysis_result[1]/analysis_result[0][next(iter(analysis_result[0]))]

def error_message(message):
    return jsonify({'status': False, 'message': message})

def simple_success():
    #TODO finish building
    return jsonify({'status': True})

def check_cmd_integrity(json_cmd):
    """ On s'assure que le contenu n'a pas été altéré """
    #TODO : check for format
    return True

@app.route('/analysis', methods=['POST'])
def analysis():
    """ Lance l'analyse au back """
    job = request.get_json()
    if check_cmd_integrity(job):
        try:
            print('New job :', job, file=sys.stderr) #NOTE no logs in console, only in terminal
            res = run_analysis(job['type'], job['period'])
            results = res
            print('Updated : ', results, file=sys.stderr)
            return simple_success() #TODO : allow reload of page to see results
        except Exception as e:
            print(e)
            return error_message(str(e))
    return error_message('Invalid json command')

@app.errorhandler(HTTPException)
def handle_exception(err):
    """ Affiche l'erreur dans la console en cas d'erreur interceptée """
    return jsonify({'status': False, 'code': err.code, 'name': err.name, 'description': err.description})

@app.route('/')
def index():
    return render_template('/api_board.html', results=results)

if __name__ == "__main__":
    app.run(debug=True)